

function image(){
    document.querySelector(".img").children[0].src=document.querySelector(".photo").value
    // 'post.avif'
}

 function tagname(){
document.querySelector(".name").innerHTML= document.querySelector(".tag").value
}
function chname(){
    document.querySelector(".channel-name").innerHTML=document.querySelector(".chna").value
}
function view(){
    document.querySelector(".view").innerHTML=document.querySelector(".vie").value
}
function time(){
    document.querySelector(".time").innerHTML= document.querySelector(".samy").value
}
function sub(){
    document.querySelector(".contain").classList.toggle("togg")
}